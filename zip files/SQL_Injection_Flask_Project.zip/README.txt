SQL Injection Demo using Python Flask + SQLite

How to Run:
1. Install requirements: pip install -r requirements.txt
2. Run the app: python app.py
3. Open browser: http://localhost:5000
4. Try login with:
   Username: admin
   Password: admin123

5. Then try SQL Injection:
   Username: admin' --
   Password: [leave blank]

You'll bypass authentication.

Fix (not implemented in this version):
Use parameterized queries:
  c.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password))