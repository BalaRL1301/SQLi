Instructions for Spring Boot SQL Injection Demo

1. Prerequisites:
   - Java 11+ and Maven
   - MySQL running on localhost

2. Create database and table in MySQL:
   CREATE DATABASE sql_injection_demo;
   USE sql_injection_demo;
   CREATE TABLE users (username VARCHAR(50), password VARCHAR(50));
   INSERT INTO users VALUES ('admin', 'admin123');

3. Project Files:
   This example includes a basic vulnerable repository with hardcoded SQL query.

4. To Run:
   - Place the files in an IDE (like IntelliJ)
   - Run as a Spring Boot application
   - Visit: http://localhost:8080/login

5. Try:
   Username: admin
   Password: admin123

   Then try SQL Injection:
   Username: admin' --
   Password: [blank]

6. Fix:
   Replace Statement with PreparedStatement.